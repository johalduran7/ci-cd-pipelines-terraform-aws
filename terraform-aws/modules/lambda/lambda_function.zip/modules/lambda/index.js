// index.js
const AWS = require('aws-sdk');
const ssm = new AWS.SSM();

exports.handler = async (event) => {
    try {
        const params = {
            Path: '/my-app/dev/',  // Specify the path to your parameters
            Recursive: true,
            WithDecryption: true // Set to true if you want to decrypt SecureString parameters
        };
        
        const response = await ssm.getParametersByPath(params).promise();
        
        console.log('Parameters:', response.Parameters);
        return {
            statusCode: 200,
            body: JSON.stringify(response.Parameters)
        };
    } catch (error) {
        console.error('Error retrieving parameters:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error.message })
        };
    }
};

